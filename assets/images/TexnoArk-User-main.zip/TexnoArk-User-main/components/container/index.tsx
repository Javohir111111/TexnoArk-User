const Index = ({ children }: any) => {
  return <div className="max-w-[1360px] w-full mx-auto">{children}</div>;
};

export default Index;
